const registerSchema = require('./register')
const loginSchema = require('./login')

module.exports = {
    registerSchema,
    loginSchema
}